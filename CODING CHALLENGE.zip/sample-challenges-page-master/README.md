# sample-challenges-page

A sample web page for listing competitive coding challenges made using HTML, vanilla CSS and JS.

Hosted at https://harshkapadia2.github.io/sample-challenges-page/

NOTE: If the page appears a little wonky (elements are not properly aligned or contained in their buttons), please clear the browser cache and refresh. Windows users can use <kbd>ctrl</kbd> + <kbd>shift</kbd> + <kbd>R</kbd>. The Dev Tools' Network tab can also be used.
